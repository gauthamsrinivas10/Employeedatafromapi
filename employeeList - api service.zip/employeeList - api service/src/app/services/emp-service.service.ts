import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IEmployee from '../interface/employee2';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {

  constructor(private http:HttpClient) { }
  employeeList : IEmployee[] = [];
  getService() {
    return this.http.get<IEmployee[]>("http://localhost:4500/employees")
  }
}
