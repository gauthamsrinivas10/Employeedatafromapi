import { Directive , ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[employeeColor]'
})
export class ColorDirective {

  constructor(private el : ElementRef) { }

  @HostListener("mouseover") mouseover(){
    console.log("mouseover")
    this.el.nativeElement.style.backgroundColor = "green"
      }
    
      @HostListener("mouseout") mouseout(){
        console.log("mouseout")
        this.el.nativeElement.style.backgroundColor = ""
      }

}
