import { Component, OnDestroy, OnInit } from '@angular/core';
import IEmployee from 'src/app/interface/employee2';
import { EmpServiceService } from 'src/app/services/emp-service.service';

@Component({
  selector: 'employee-content',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, OnDestroy{

  
  
employeeList : IEmployee[] = [];
  constructor( private list: EmpServiceService) { 
    this.employeeList = list.employeeList;
  }

  
  ngOnInit(): void {
    this.list.getService().subscribe((data)=>{
      console.log(data)
      this.employeeList = data;
    })
  }
  ngOnDestroy() : void {

  }

}
